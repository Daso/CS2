<?php

class Persistence {
    private $_instancia;

    private static function getInstancia(){
        if($this->_instancia == null){
            $this->_instancia = new Persistence();
        }else{
            self::getInstancia();
        }
    }
    private $_cn;
    public function __construct() {
       $this->_cn= mysql_connect("localhost","root");
       $db = mysql_select_db("impCol", $this->_cn);
    }
}
?>
