<?php
header("location:View/IngresoForm.html");
?>
