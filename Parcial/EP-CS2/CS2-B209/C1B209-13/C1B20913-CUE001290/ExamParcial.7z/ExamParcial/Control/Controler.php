<?php
require_once '../Model/Pago.php';
require_once '../Persistence/Persistence.php';

class Controler {
 private $_colImp = Array();
 private $_pago;
 public function __construct() {

      $mes = $_POST['mes'];
      $monto = $_POST['monto'];

     if($_POST['monto']>2500){
          return  $impuesto = 0.007;
     }else{
           return $impuesto = 0.01;
     }
     $this->_pago = new Pago($mes, $monto, $impuesto);
     $this->_colImp[] = $this->_pago;
     return $this->_colImp;
    }

 public function addAll(){
 $cn = new Persistence();
$sql = "INSERT INTO 'Mes'('Nombre','Monto','Impuesto')
        VALUES ( '".$this->_colImp->getMes()."','".$this->_colImp->getMonto()."','".
                   $this->_colImp->getImpuesto()."')" ;
 }


public function mostrarResultados(){
    foreach ($this->_colImp as $pago){
      $monto = $pago->getMonto;
      $acumulado = $this->_pago->calcularImpuestoAnual($monto);
      if($acumulado> 24000){
      
      }


    }
    self::_mostrarResultado();

}

private static function _mostrarResultado(){
    require_once '../View/Result.html';
}
?>
