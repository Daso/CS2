<?php

class Pago {
    private $_mes;
    private $_monto;
    private $_impuesto;
   // private $_mensual;
    private $_anual;
    private $_impExtra;

    public function __construct($mes,$monto,$impuesto) {
        $this->_mes = $mes;
        $this->_monto = $monto;
        $this->_impuesto = $this->_monto * $impuesto;
    }

   /* public function calcularImpuestoMensual($impuesto){
        $this->_mensual = $this->_monto*$impuesto;
    }*/

     public function calcularImpuestoAnual($monto){
        $this->_anual = $this->_anual + $monto;
    }

     public function calcularImpuestoExtraordinario($acumulado){
        $this->_impExtra = $acumulado*0.3;
    }

    public function getMonto(){return $this->_monto;}
    public function getImpuesto(){return $this->_impuesto;}
   // public function getMensual(){return $this->_mensual;}
    public function getAnual(){return $this->_anual;}
    public function getImpExtra(){return $this->_impExtra;}
    public function getMes(){return $this->_mes;}
}
?>
