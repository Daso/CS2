<?php
require_once '../control/Controlador.php';

class ViewPHP {


    public static function run()
    {
        $miLogic= new Controlador();

        if(!isset($_GET['opcion']))
        {
              self::showFormularioParaIngresar($miLogic->getMes());
        }
        else
        {
            $opcion= $_GET['opcion'];
            switch($opcion)
            {
                case 'ingresar':
                                if($miLogic->getMes()<=11){
                                    $miLogic->insert($_POST['ingreso']);
                                    
                                    $message = "se inserto exitosamente ingreso del mes ".$miLogic->getMes();
                                    self::showAction($message);
                                }
                                else
                                {
                                    $message="se llego al fin de año.  No se pueden ingresar más datos.";
                                    self::showAction($message);

                                }
                                    break;

                case 'extraordinario':   $impuestos=$miLogic->getAll();
                                        $acumuladoIngresos=0;
                                        $acumuladoImpuestos=0;
                                         foreach($impuestos as $impuesto)
                                         {
                                             $acumuladoImpuestos=$acumuladoImpuestos+$impuesto->getImpuesto();
                                             $acumuladoIngresos=$acumuladoIngresos +$impuesto->getIngreso();
                                         }
                                         $extraordinario=0;
                                         if($acumuladoIngresos-$acumuladoImpuestos>24000)
                                         {
                                             //ocurre imp extraoridnario
                                             $extraordinario=.3*($acumuladoIngresos-$acumuladoImpuestos);

                                         }
                                         $message="";
                                         if($extraordinario!=0)
                                         {
                                             $message="Hay un impuesto extraordinario de ".$extraordinario;
                                         }
                                         else
                                         {
                                             $message="No hay lugar a impuesto extraordinario";
                                         }
                                         self::showExtraordinario($message);
                    
                                        break;

                   case 'listar':  $impuestos=$miLogic->getAll();

                                    self::showListadoAcumulado($impuestos,count($miLogic->getAll()));
                                    break;

                   default: break;

            }

        }

    }
    public static function showExtraordinario($message)
    {
        require_once 'impuestoExtraordinario.html';
    }

    public static function showListadoAcumulado($impuestos,$meses)
    {
        require_once 'listarAcumulado.html';
    }
    public static function showAction($message)
    {
        require_once 'action.html';
    }

    public static function showFormularioParaIngresar($mes)
    {
        require_once 'formularioIngresarPorMes.html';
    }
}
ViewPHP::run();
?>
