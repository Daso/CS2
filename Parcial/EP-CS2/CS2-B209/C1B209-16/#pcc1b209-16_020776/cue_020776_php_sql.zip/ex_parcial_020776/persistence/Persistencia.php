<?php

class Persistencia {

    private $_conexion;
    private static $_instance=null;

    public static function getInstance()
    {
        if(self::$_instance==null)
        {
            self::$_instance=new Persistencia();
        }
        return self::$_instance;
    }
    public function getAll()
    {
        $query= "select * from taxes";
        $result= $this->ejecutarQuery($query,1);
        return $result;

    }

    public function insert($ingreso,$impuesto)
    {

        $query= "insert into taxes (id, ingreso, impuesto)
values (NULL,'$ingreso','$impuesto');";
        $this->ejecutarQuery($query, 2);

    }

    public function ejecutarQuery($query,$tipo)
    {
        try {

            $result= mysql_query($query,$this->_conexion);
            if($tipo==1)
            {
                $arreglo=array();
                while($row= mysql_fetch_assoc($result))
                {
                    $arreglo[]=$row;
                }
                mysql_free_result($result);
                return $arreglo;
            }

        } catch (Exception $e) {
            error_log($e->getMessage(), 3, '../log/Error.log');
            error_log($query, 3, '../log/Error.log');

            throw $e;
        }

    }

    public function  __construct() {

        try {
            $this->_conexion= mysql_connect('localhost', 'root');
            if(!$this->_conexion)
            {
                $this->_conexion=null;
                throw new Exception("problems connecting to db");
            }
            $db= mysql_select_db('impuestos',$this->_conexion);
            if(!$db)
            {
                mysql_close($this->_conexion);
                $this->_conexion=null;
                throw new Exception("problems no such db exists");
            }

        } catch (Exception $e) {
            error_log($e->getMessage(), 3, '../log/Error.log');
            throw $e;
        }



    }

}
Persistencia::getInstance();
?>
