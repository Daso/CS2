<?php
require_once '../persistence/Persistencia.php';
class Impuesto {

    private $_id;
    private $_ingreso;
    private $_impuesto;

    public function getId(){return $this->_id;}
    public function getIngreso(){return $this->_ingreso;}
    public function getImpuesto(){return $this->_impuesto;}
    public function  __construct($id="",$ingreso=0) {

        $this->_id=$id;
        $this->_ingreso=$ingreso;
        if ($this->_ingreso>2500)
        {
            $this->_impuesto=.01*$this->_ingreso;
        }
        else
        {
            $this->_impuesto=0.007*$this->_ingreso;
        }
    }
    public function insertar()
    {
        $instance=Persistencia::getInstance();
        $instance->insert($this->getIngreso(),$this->_impuesto);

    }
    public function getAll()
    {
        $instance=Persistencia::getInstance();
        $result=$instance->getAll();
        $impuestos=array();
        foreach($result as $row)
        {
            $id=$row['id'];
            $ingreso=$row['ingreso'];
            $impuesto=$row['impuesto'];
            $obj= new Impuesto($id, $ingreso);
            $impuestos[]=$obj;
        }
        return $impuestos;
    }
}
?>
