<?php
    header('location:view/ViewPHP.php');
    
        ?>
    