<?php
require_once '../persistence/Persistencia.php';
class Test {
 public static function run()
 {
     $instance= Persistencia::getInstance();
     //$instance->insert(56.7,12.5);
     print_r($instance->getAll());
 }
}
Test::run();
?>
