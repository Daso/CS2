<?php
require_once '../model/Impuesto.php';
session_start();

class Controlador {

    private $mes;

    public function  __construct() {
        if(!isset($_SESSION['mes']))
        {
            $this->mes=0;
        }
        else
        {
            $this->mes=$_SESSION['mes'];
        }
    }

    public function getMes(){return $this->mes;}
    public function getAll()
    {
        $impuesto= new Impuesto();
        return $impuesto->getAll();
    }
    public function insert($ingreso)
    {
        $impuesto= new Impuesto(null, $ingreso);

        $impuesto->insertar();
        $this->mes++;
        $_SESSION['mes']=$this->mes;
    }
}
?>
